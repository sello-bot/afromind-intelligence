import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LUNA AI — Afromind Tech",
  description: "LUNA AI — The Intelligence. By Afromind Tech.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
