"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { ArrowUp, BrainCircuit, ChevronDown, MessageSquarePlus, PanelLeftClose, Plus, Sparkles, Trash2 } from "lucide-react";

type Conversation = { id: string; title: string; created_at: string };
type Message = { id: string; conversation_id: string; role: string; content: string; model?: string };

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const OWNER_KEY = "luna_owner_id";

function getOwnerId() {
  if (typeof window === "undefined") return "";
  let id = localStorage.getItem(OWNER_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(OWNER_KEY, id);
  }
  return id;
}

export default function Home() {
  const [ownerId, setOwnerId] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeId, setActiveId] = useState("");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState("default");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [error, setError] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { setOwnerId(getOwnerId()); }, []);
  useEffect(() => {
    if (!ownerId) return;
    fetch(`${API}/api/conversations?owner_id=${encodeURIComponent(ownerId)}`)
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(setConversations).catch(() => setError("Cannot reach LUNA's backend. Start the API on port 8000."));
  }, [ownerId]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function openConversation(id: string) {
    setActiveId(id);
    const response = await fetch(`${API}/api/conversations/${id}?owner_id=${encodeURIComponent(ownerId)}`);
    if (response.ok) setMessages(await response.json());
  }

  function newChat() { setActiveId(""); setMessages([]); setInput(""); setError(""); }

  async function removeConversation(id: string) {
    await fetch(`${API}/api/conversations/${id}?owner_id=${encodeURIComponent(ownerId)}`, { method: "DELETE" });
    setConversations(items => items.filter(item => item.id !== id));
    if (activeId === id) newChat();
  }

  async function sendMessage(event: FormEvent) {
    event.preventDefault();
    const text = input.trim();
    if (!text || loading || !ownerId) return;
    setInput(""); setError(""); setLoading(true);
    const tempUser: Message = { id: crypto.randomUUID(), conversation_id: activeId, role: "user", content: text };
    const tempAssistant: Message = { id: crypto.randomUUID(), conversation_id: activeId, role: "assistant", content: "" };
    setMessages(current => [...current, tempUser, tempAssistant]);

    try {
      const response = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ owner_id: ownerId, conversation_id: activeId || null, message: text, model: model === "default" ? null : model }),
      });
      if (!response.ok || !response.body) throw new Error(await response.text());
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let assistantText = "";
      let conversationId = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() || "";
        for (const event of events) {
          const dataLine = event.split("\n").find(line => line.startsWith("data: "));
          if (!dataLine) continue;
          const data = JSON.parse(dataLine.slice(6));
          if (data.token) {
            assistantText += data.token;
            setMessages(current => current.map(m => m.id === tempAssistant.id ? { ...m, content: assistantText } : m));
          }
          if (data.conversation_id) conversationId = data.conversation_id;
          if (data.error) throw new Error(data.error);
        }
      }
      if (conversationId) setActiveId(conversationId);
      const list = await fetch(`${API}/api/conversations?owner_id=${encodeURIComponent(ownerId)}`);
      if (list.ok) setConversations(await list.json());
      if (!assistantText) setError("LUNA returned an empty response. Check your provider configuration.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
      setMessages(current => current.filter(m => m.id !== tempAssistant.id));
    } finally { setLoading(false); }
  }

  const hasMessages = messages.length > 0;

  return (
    <main className="flex h-screen overflow-hidden bg-[#050705] text-[#F4F7F1]">
      {sidebarOpen && <aside className="hidden w-[270px] shrink-0 border-r border-white/[0.07] bg-[#090D09] p-4 md:flex md:flex-col">
        <div className="mb-8 flex items-center gap-3 px-2 pt-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#7CFC00]/30 bg-[#7CFC00]/10 text-[#7CFC00]"><BrainCircuit size={23}/></div>
          <div><div className="font-semibold tracking-wide">AFROMIND</div><div className="text-xs tracking-[0.22em] text-[#7CFC00]">LUNA AI</div></div>
        </div>
        <button onClick={newChat} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-3 text-sm transition hover:border-[#7CFC00]/40 hover:bg-[#7CFC00]/[0.06]"><MessageSquarePlus size={17} className="text-[#7CFC00]"/> New conversation <Plus size={16} className="ml-auto text-white/40"/></button>
        <div className="mb-3 mt-8 px-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/35">Recent conversations</div>
        <div className="flex-1 space-y-1 overflow-y-auto">
          {conversations.map(c => <div key={c.id} className={`group flex items-center gap-2 rounded-lg px-2 py-2 ${activeId === c.id ? "bg-white/[0.07]" : "hover:bg-white/[0.04]"}`}>
            <button onClick={() => openConversation(c.id)} className="min-w-0 flex-1 truncate text-left text-sm text-white/70">{c.title}</button>
            <button onClick={() => removeConversation(c.id)} aria-label="Delete conversation" className="text-white/20 opacity-0 transition hover:text-red-400 group-hover:opacity-100"><Trash2 size={14}/></button>
          </div>)}
          {conversations.length === 0 && <p className="px-2 text-xs text-white/30">Your conversations will appear here.</p>}
        </div>
        <div className="border-t border-white/[0.07] pt-4"><div className="text-xs font-medium">LUNA AI</div><div className="mt-1 text-[11px] text-white/35">The Intelligence · By Afromind Tech</div></div>
      </aside>}

      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-[68px] shrink-0 items-center justify-between border-b border-white/[0.07] px-4 md:px-7">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="rounded-lg p-2 text-white/50 hover:bg-white/5 hover:text-white"><PanelLeftClose size={18}/></button>
            <span className="text-sm font-medium text-white/80">LUNA AI</span><span className="rounded-full border border-[#7CFC00]/20 bg-[#7CFC00]/[0.07] px-2 py-1 text-[10px] text-[#7CFC00]">Preview</span>
          </div>
          <button className="flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-white/60 hover:bg-white/5" onClick={() => setModel(model === "default" ? "gpt-4o-mini" : "default")}> {model === "default" ? "Default model" : model} <ChevronDown size={14}/></button>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto flex min-h-full w-full max-w-4xl flex-col px-4 pb-8 pt-8 md:px-8">
            {!hasMessages ? <div className="flex flex-1 flex-col items-center justify-center pb-20 text-center">
              <div className="mb-7 flex h-[76px] w-[76px] items-center justify-center rounded-[25px] border border-[#7CFC00]/25 bg-[#7CFC00]/[0.07] shadow-[0_0_70px_rgba(124,252,0,0.08)]"><Sparkles size={34} className="text-[#7CFC00]"/></div>
              <p className="mb-3 text-xs font-medium uppercase tracking-[0.3em] text-[#7CFC00]/80">AFROMIND LUNA AI</p>
              <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">What can I help you with?</h1>
              <p className="mt-3 max-w-md text-sm leading-6 text-white/40">Your intelligent workspace for ideas, research, code and discovery.</p>
              <div className="mt-10 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
                {["Help me understand a complex topic","Write or debug some code","Analyse an idea for my business","Help me plan a project"].map((item, i) => <button key={item} onClick={() => setInput(item)} className="rounded-xl border border-white/[0.09] bg-white/[0.025] p-4 text-left text-sm text-white/60 transition hover:border-[#7CFC00]/30 hover:bg-[#7CFC00]/[0.04]">{item}</button>)}
              </div>
            </div> : <div className="space-y-8 py-5">
              {messages.map(message => <div key={message.id} className={`flex gap-4 ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                {message.role === "assistant" && <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#7CFC00]/10 text-[#7CFC00]"><Sparkles size={17}/></div>}
                <div className={`max-w-[85%] whitespace-pre-wrap text-sm leading-7 ${message.role === "user" ? "rounded-2xl bg-white/[0.07] px-4 py-3 text-white/90" : "pt-1 text-white/80"}`}>{message.content || (loading && message.role === "assistant" ? <span className="animate-pulse text-[#7CFC00]">LUNA is thinking…</span> : "")}</div>
              </div>)}
              <div ref={bottomRef}/>
            </div>}
            {error && <div className="mt-4 rounded-xl border border-red-500/20 bg-red-500/[0.06] p-3 text-xs leading-5 text-red-300">{error}</div>}
          </div>
        </div>

        <div className="shrink-0 px-4 pb-5 md:px-8">
          <form onSubmit={sendMessage} className="mx-auto max-w-4xl">
            <div className="rounded-2xl border border-white/[0.12] bg-[#0B100B] p-3 shadow-2xl transition focus-within:border-[#7CFC00]/35">
              <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(e as unknown as FormEvent); } }} placeholder="Message LUNA AI..." rows={2} className="max-h-40 w-full resize-none bg-transparent px-2 py-2 text-sm text-white outline-none placeholder:text-white/30"/>
              <div className="flex items-center justify-between px-1 pt-2">
                <span className="text-[10px] text-white/25">LUNA AI can make mistakes. Verify important information.</span>
                <button disabled={!input.trim() || loading} type="submit" className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#7CFC00] text-black transition hover:bg-[#9BFF38] disabled:cursor-not-allowed disabled:opacity-30"><ArrowUp size={19}/></button>
              </div>
            </div>
          </form>
          <p className="mt-2 text-center text-[10px] text-white/20">AFROMIND TECH · LUNA AI — THE INTELLIGENCE</p>
        </div>
      </section>
    </main>
  );
}
